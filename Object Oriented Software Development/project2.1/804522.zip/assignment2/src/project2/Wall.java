package project2;

public class Wall extends Sprite {
	public Wall(float x, float y) {
		super("res/wall.png", x, y);
	}
}
