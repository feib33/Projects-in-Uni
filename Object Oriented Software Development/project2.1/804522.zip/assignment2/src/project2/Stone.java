package project2;

public class Stone extends Sprite {
	public Stone(float x, float y) {
		super("res/stone.png", x, y);
	}
}
